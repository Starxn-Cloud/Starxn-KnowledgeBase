<!-- _coverpage.md -->

![logo](https://starxn.com/themes/web/starxn/assets/img/favicon.png)

# 星辰 Knowledge Base <small>3.5</small>

> 纵有千言万语 不及用户感言

- 简洁 轻量 迅速
- 上手简单

[星辰云服务状态](https://status.starxn.com/)
[星辰云官网](https://starxn.com/)
[星辰 Timeline](https://)

<!-- 背景图片 -->

![](https://img.afqaq.com/images/2022/03/29/services_img01.png)
